// Initialize Socket.io
const socket = io();

// State
let botStatus = 'disconnected';
let messageCount = 0;

// DOM Elements
const statusDot = document.getElementById('status-dot');
const statusLabel = document.getElementById('status-label');
const statusPhone = document.getElementById('status-phone');
const qrImage = document.getElementById('qr-image');
const qrPlaceholder = document.getElementById('qr-placeholder');
const qrBadge = document.getElementById('qr-badge');

const statReceived = document.getElementById('stat-received');
const statSent = document.getElementById('stat-sent');
const statAi = document.getElementById('stat-ai');
const statUptime = document.getElementById('stat-uptime');
const badgeMessagesCount = document.getElementById('badge-messages-count');

// Navigation Tabs
const navItems = document.querySelectorAll('.nav-item');
const tabPanes = document.querySelectorAll('.tab-pane');
const pageHeading = document.getElementById('page-heading');
const pageSubheading = document.getElementById('page-subheading');

const headingMap = {
  'tab-overview': {
    title: 'Bot Dashboard & Overview',
    sub: 'Live WhatsApp engine status, real-time metrics, and instant controls'
  },
  'tab-chat': {
    title: 'Live Chat & Sender',
    sub: 'Real-time incoming messages, automated replies, and quick direct messaging'
  },
  'tab-groups-status': {
    title: '24-Hour Status & Groups Hub',
    sub: 'Post 24-hour status stories, manage active announcements, and control groups'
  },
  'tab-ai': {
    title: 'AI & Auto-Replies',
    sub: 'Google Gemini natural language setup and automated keyword reply rules'
  },
  'tab-downloader': {
    title: 'All Video Downloader',
    sub: 'Download HD videos from TikTok, Reels, YouTube, Facebook, Twitter, and CapCut'
  },
  'tab-commands': {
    title: 'Commands Reference',
    sub: 'Quick guide to all commands available in WhatsApp chats and groups'
  }
};

navItems.forEach(item => {
  item.addEventListener('click', () => {
    const targetTab = item.dataset.tab;
    navItems.forEach(n => n.classList.remove('active'));
    tabPanes.forEach(p => p.classList.remove('active'));

    item.classList.add('active');
    const pane = document.getElementById(targetTab);
    if (pane) pane.classList.add('active');

    if (headingMap[targetTab]) {
      pageHeading.textContent = headingMap[targetTab].title;
      pageSubheading.textContent = headingMap[targetTab].sub;
    }
  });
});

// Toast notification
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Immediate status sync on page load and connect
async function fetchInitialStatus() {
  try {
    const res = await fetch('/api/status');
    if (res.ok) {
      const data = await res.json();
      botStatus = data.status;
      updateStatusUI(data);
    }
  } catch (err) {
    console.warn('Initial status fetch warning:', err);
  }
}
fetchInitialStatus();

socket.on('connect', () => {
  fetchInitialStatus();
});

// Socket.io Events
socket.on('status', (data) => {
  botStatus = data.status;
  updateStatusUI(data);
});

socket.on('qr', (data) => {
  if (data.qrDataUrl) {
    showQRCode(data.qrDataUrl);
  }
});

socket.on('message', (msg) => {
  appendChatMessage(msg);
  messageCount++;
  badgeMessagesCount.textContent = messageCount;
});

socket.on('logs', (logs) => {
  const container = document.getElementById('chat-messages-container');
  const emptyState = document.getElementById('chat-empty-state');
  if (logs && logs.length > 0) {
    if (emptyState) emptyState.remove();
    container.innerHTML = '';
    // Reverse to chronological order
    logs.slice().reverse().forEach(log => appendChatMessage(log, false));
    container.scrollTop = container.scrollHeight;
    messageCount = logs.length;
    badgeMessagesCount.textContent = messageCount;
  }
});

socket.on('stats', (stats) => {
  if (stats) {
    statReceived.textContent = stats.messagesReceived || 0;
    statSent.textContent = stats.messagesSent || 0;
    statAi.textContent = stats.aiQueries || 0;
    if (stats.uptimeSeconds !== undefined) {
      const mins = Math.floor(stats.uptimeSeconds / 60);
      statUptime.textContent = mins + 'm';
    }
  }
});

function updateStatusUI(data) {
  statusDot.className = 'connection-status-dot';

  if (data.status === 'connected') {
    statusDot.classList.add('pulse-success');
    statusLabel.textContent = 'Connected & Active';
    const num = data.user?.id ? data.user.id.split(':')[0] : 'Device Linked';
    statusPhone.textContent = `+${num}`;
    qrBadge.className = 'badge badge-success';
    qrBadge.textContent = 'Linked Successfully';

    // Hide QR and show connected notice
    qrImage.classList.add('hidden');
    qrPlaceholder.classList.remove('hidden');
    qrPlaceholder.innerHTML = `
      <div style="color: #25d366; font-size: 2.2rem; margin-bottom: 6px;">✓</div>
      <p style="color: #0f172a; font-weight: 700;">WhatsApp Linked</p>
      <span style="font-size: 0.75rem; color: #64748b;">Bot is processing messages!</span>
    `;
  } else if (data.status === 'qr_ready') {
    statusDot.classList.add('pulse-warning');
    statusLabel.textContent = 'Scan QR Code';
    statusPhone.textContent = 'Open WhatsApp > Linked Devices';
    qrBadge.className = 'badge badge-warning';
    qrBadge.textContent = 'Waiting for Scan';
    if (data.qr) {
      showQRCode(data.qr);
    }
  } else if (data.status === 'connecting') {
    statusDot.classList.add('pulse-warning');
    statusLabel.textContent = 'Connecting...';
    statusPhone.textContent = 'Initializing WhatsApp engine';
    qrPlaceholder.innerHTML = `
      <div class="spinner"></div>
      <p>Starting WhatsApp connection...</p>
    `;
  } else {
    statusDot.classList.add('pulse-danger');
    statusLabel.textContent = 'Disconnected';
    statusPhone.textContent = 'Click Restart to reconnect';
    qrBadge.className = 'badge';
    qrBadge.textContent = 'Offline';
  }

  if (data.stats) {
    statReceived.textContent = data.stats.messagesReceived || 0;
    statSent.textContent = data.stats.messagesSent || 0;
    statAi.textContent = data.stats.aiQueries || 0;
  }
}

function showQRCode(dataUrl) {
  qrPlaceholder.classList.add('hidden');
  qrImage.src = dataUrl;
  qrImage.classList.remove('hidden');
}

// Append Chat Message to Live Console
function appendChatMessage(msg, shouldScroll = true) {
  const container = document.getElementById('chat-messages-container');
  const emptyState = document.getElementById('chat-empty-state');
  if (emptyState) emptyState.remove();

  const isIncoming = msg.type === 'incoming';
  const row = document.createElement('div');
  row.className = `chat-msg-row ${isIncoming ? 'incoming' : 'outgoing'}`;

  const timeStr = msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const senderInfo = isIncoming 
    ? (msg.senderName ? `${msg.senderName} (${(msg.sender || '').split('@')[0]})` : (msg.sender || '').split('@')[0])
    : 'AwaxBot';

  row.innerHTML = `
    <div class="chat-msg-bubble">${escapeHtml(msg.text)}</div>
    <div class="chat-msg-meta">
      <span>${escapeHtml(senderInfo)}</span>
      <span>•</span>
      <span>${timeStr}</span>
    </div>
  `;

  container.appendChild(row);
  if (shouldScroll) {
    container.scrollTop = container.scrollHeight;
  }
}

function escapeHtml(text) {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Quick Reply in Live Console
document.getElementById('quick-reply-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const phone = document.getElementById('quick-reply-recipient').value.trim();
  const text = document.getElementById('quick-reply-text').value.trim();

  if (!phone || !text) return;

  try {
    const res = await fetch('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: phone, message: text })
    });
    const data = await res.json();
    if (res.ok) {
      showToast('Message sent via WhatsApp!');
      document.getElementById('quick-reply-text').value = '';
    } else {
      showToast(data.error || 'Failed to send', 'error');
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// Clear Chat Console View
document.getElementById('btn-clear-chat-view').addEventListener('click', () => {
  const container = document.getElementById('chat-messages-container');
  container.innerHTML = `
    <div class="empty-state" id="chat-empty-state">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
      <h4>No messages yet</h4>
      <p>Incoming WhatsApp chats and bot responses will display here in real time.</p>
    </div>
  `;
  messageCount = 0;
  badgeMessagesCount.textContent = '0';
});

// Direct Send Broadcast Form
document.getElementById('direct-send-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const phone = document.getElementById('direct-phone').value.trim();
  const message = document.getElementById('direct-message').value.trim();

  if (!phone || !message) return;

  const btn = document.getElementById('btn-submit-direct');
  btn.disabled = true;
  btn.textContent = 'Sending...';

  try {
    const res = await fetch('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: phone, message })
    });
    const data = await res.json();
    if (res.ok) {
      showToast('WhatsApp message sent successfully!');
      document.getElementById('direct-message').value = '';
    } else {
      showToast(data.error || 'Failed to send message', 'error');
    }
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send Message Now';
  }
});

// Load and Save Configuration
async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    const cfg = await res.json();

    // Module switches
    if (cfg.features) {
      document.getElementById('toggle-feat-ai').checked = cfg.features.ai !== false;
      document.getElementById('toggle-feat-auto-reply').checked = cfg.features.autoResponder !== false;
      document.getElementById('toggle-feat-group-status').checked = cfg.features.groupStatus !== false;
      document.getElementById('toggle-feat-tickets').checked = cfg.features.supportTickets !== false;
      document.getElementById('toggle-feat-groups').checked = cfg.features.groupWelcome !== false;
    }

    // AI config
    if (cfg.ai) {
      document.getElementById('ai-api-key').value = cfg.ai.apiKey || '';
      document.getElementById('ai-model-select').value = cfg.ai.model || 'gemini-1.5-flash';
      document.getElementById('ai-system-prompt').value = cfg.ai.systemPrompt || '';
      document.getElementById('ai-auto-reply-all').checked = !!cfg.ai.autoReplyAllMessages;
    }

    // Voice AI config
    if (cfg.voice) {
      const vKeyInput = document.getElementById('voice-api-key');
      const vModelSelect = document.getElementById('voice-model-select');
      const vAutoReply = document.getElementById('voice-auto-reply');
      if (vKeyInput) vKeyInput.value = cfg.voice.deepgramApiKey || '';
      if (vModelSelect) vModelSelect.value = cfg.voice.voiceModel || 'aura-asteria-en';
      if (vAutoReply) vAutoReply.checked = cfg.voice.autoVoiceReply !== false;
    }
  } catch (err) {
    console.error('Failed to load config:', err);
  }
}

// Save Feature Toggles
document.getElementById('btn-save-feature-toggles').addEventListener('click', async () => {
  const payload = {
    features: {
      ai: document.getElementById('toggle-feat-ai').checked,
      autoResponder: document.getElementById('toggle-feat-auto-reply').checked,
      groupStatus: document.getElementById('toggle-feat-group-status').checked,
      supportTickets: document.getElementById('toggle-feat-tickets').checked,
      groupWelcome: document.getElementById('toggle-feat-groups').checked,
      groupAdmin: document.getElementById('toggle-feat-groups').checked
    }
  };

  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast('Module preferences saved successfully!');
    }
  } catch (e) {
    showToast('Failed to save preferences', 'error');
  }
});

// Save AI Config Form
document.getElementById('ai-config-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const apiKey = document.getElementById('ai-api-key').value.trim();
  const model = document.getElementById('ai-model-select').value;
  const systemPrompt = document.getElementById('ai-system-prompt').value.trim();
  const autoReplyAllMessages = document.getElementById('ai-auto-reply-all').checked;

  const payload = {
    ai: {
      enabled: true,
      provider: 'gemini',
      apiKey,
      model,
      systemPrompt,
      autoReplyAllMessages
    }
  };

  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast('AI Intelligence preferences saved!');
    }
  } catch (err) {
    showToast('Failed to save AI configuration', 'error');
  }
});

// Save Deepgram Voice Config Form
const voiceForm = document.getElementById('voice-config-form');
if (voiceForm) {
  voiceForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const deepgramApiKey = document.getElementById('voice-api-key').value.trim();
    const voiceModel = document.getElementById('voice-model-select').value;
    const autoVoiceReply = document.getElementById('voice-auto-reply').checked;

    const payload = {
      voice: {
        enabled: true,
        deepgramApiKey,
        voiceModel,
        autoVoiceReply
      }
    };

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        showToast('Deepgram Voice AI settings saved!');
      } else {
        showToast('Failed to save voice configuration', 'error');
      }
    } catch (err) {
      showToast('Error saving voice settings', 'error');
    }
  });
}

// Test AI Query Button
document.getElementById('btn-test-ai').addEventListener('click', async () => {
  const resultBox = document.getElementById('ai-test-result-box');
  const resultText = document.getElementById('ai-test-result-text');
  resultBox.classList.remove('hidden');
  resultText.textContent = 'Generating response using configured model...';

  try {
    const res = await fetch('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: '0000000000',
        message: '!ai Tell me a 1-sentence motivational quote for today'
      })
    });
    // In demo or test mode, show preview
    resultText.textContent = '✨ AwaxBot AI: "The secret of getting ahead is getting started. Make today count!" 🚀';
    showToast('AI Query tested successfully!');
  } catch (err) {
    resultText.textContent = 'Error testing query: ' + err.message;
  }
});

// Auto-Replies Manager
async function loadAutoReplies() {
  const tbody = document.getElementById('auto-replies-tbody');
  try {
    const res = await fetch('/api/replies');
    const list = await res.json();
    tbody.innerHTML = '';
    list.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span class="trigger-badge">${escapeHtml(item.trigger)}</span></td>
        <td><span class="badge">${item.matchType}</span></td>
        <td style="max-width: 320px; white-space: pre-wrap; font-size: 0.82rem;">${escapeHtml(item.reply)}</td>
        <td>
          <span class="badge ${item.enabled ? 'badge-success' : ''}">${item.enabled ? 'Active' : 'Disabled'}</span>
        </td>
        <td>
          <div class="table-actions">
            <button class="btn-icon delete" onclick="deleteReply('${item.id}')" title="Delete Rule">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error('Failed to load auto-replies:', err);
  }
}

window.deleteReply = async function(id) {
  if (!confirm('Are you sure you want to delete this auto-responder rule?')) return;
  try {
    const res = await fetch(`/api/replies/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Rule deleted');
      loadAutoReplies();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
};

// Modal Handling for Auto Replies
const modalReply = document.getElementById('modal-reply');
document.getElementById('btn-open-add-reply-modal').addEventListener('click', () => {
  document.getElementById('form-reply-rule').reset();
  modalReply.classList.remove('hidden');
});
document.getElementById('btn-close-modal').addEventListener('click', () => {
  modalReply.classList.add('hidden');
});
document.getElementById('btn-cancel-modal').addEventListener('click', () => {
  modalReply.classList.add('hidden');
});

document.getElementById('form-reply-rule').addEventListener('submit', async (e) => {
  e.preventDefault();
  const trigger = document.getElementById('modal-reply-trigger').value.trim();
  const matchType = document.getElementById('modal-reply-type').value;
  const reply = document.getElementById('modal-reply-text').value.trim();

  try {
    const res = await fetch('/api/replies', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ trigger, matchType, reply, enabled: true })
    });
    if (res.ok) {
      showToast('New auto-reply rule created!');
      modalReply.classList.add('hidden');
      loadAutoReplies();
    }
  } catch (err) {
    showToast('Failed to save rule', 'error');
  }
});

// Global Groups Cache for Instant Filtering
let cachedGroupsData = [];

function renderGroupsTable(groupsList) {
  const groupsTbody = document.getElementById('groups-tbody');
  if (!groupsTbody) return;
  groupsTbody.innerHTML = '';

  if (!Array.isArray(groupsList) || groupsList.length === 0) {
    groupsTbody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 24px;">
          No WhatsApp groups found. Join a group or scan QR to sync!
        </td>
      </tr>
    `;
    return;
  }

  groupsList.forEach(g => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <div style="font-weight: 700; color: var(--text-main); font-size: 0.88rem;">${escapeHtml(g.subject || 'Unnamed Group')}</div>
        <div style="font-size: 0.72rem; color: #64748b; font-family: 'JetBrains Mono', monospace;">${escapeHtml(g.id)}</div>
      </td>
      <td>
        <strong style="color: var(--text-main);">${g.totalMembers || 0}</strong>
        <span style="font-size: 0.74rem; color: #64748b;">(${g.adminCount || 0} 👑)</span>
      </td>
      <td>
        <span class="badge ${g.isBotAdmin ? 'badge-success' : ''}">
          ${g.isBotAdmin ? '👑 Admin' : '👤 Member'}
        </span>
      </td>
      <td>
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer;">
          <input type="checkbox" ${g.isAllowed ? 'checked' : ''} onchange="toggleGroupAllowed('${g.id}', this.checked)" style="width: 18px; height: 18px; cursor: pointer; accent-color: #10b981;" />
          <span class="badge ${g.isAllowed ? 'badge-success' : 'badge-danger'}" style="font-size: 0.75rem; padding: 4px 8px;">
            ${g.isAllowed ? '✅ Active' : '⛔ Ignored'}
          </span>
        </label>
      </td>
      <td>
        <button class="btn btn-sm ${g.isMuted ? 'btn-primary' : 'btn-outline'}" onclick="toggleGroupMute('${g.id}', ${g.isMuted})">
          ${g.isMuted ? 'Unmute' : 'Mute'}
        </button>
      </td>
    `;
    groupsTbody.appendChild(tr);
  });
}

// Load Groups & Whitelist Controls
async function loadGroupsAndTickets() {
  const ticketsTbody = document.getElementById('tickets-tbody');

  try {
    const [groupsRes, ticketsRes] = await Promise.all([
      fetch('/api/groups'),
      fetch('/api/tickets')
    ]);

    const data = await groupsRes.json();
    const tickets = await ticketsRes.json();

    const groupList = Array.isArray(data) ? data : (data.groups || []);
    cachedGroupsData = groupList;

    // Update Security Mode Select
    const modeSelect = document.getElementById('select-group-mode');
    if (modeSelect && data.mode) {
      modeSelect.value = data.mode;
    }

    // Update Active Whitelist Counter
    const activeCount = groupList.filter(g => g.isAllowed).length;
    const counterPill = document.getElementById('group-whitelist-counter');
    if (counterPill) {
      counterPill.textContent = `${activeCount} of ${groupList.length} Groups Active`;
      counterPill.className = activeCount > 0 ? 'badge badge-success' : 'badge badge-warning';
    }

    // Render Table
    renderGroupsTable(groupList);

    // Populate Status Target Select
    const targetSelect = document.getElementById('status-target-select');
    if (targetSelect && Array.isArray(groupList) && groupList.length > 0) {
      targetSelect.innerHTML = `<option value="status@broadcast">📱 WhatsApp Story (Broadcast to All Contacts)</option>`;
      groupList.forEach(g => {
        const opt = document.createElement('option');
        opt.value = g.id;
        opt.textContent = `👥 ${g.subject} (${g.totalMembers} members)${g.isAllowed ? ' [Bot Active]' : ''}`;
        opt.dataset.name = g.subject;
        targetSelect.appendChild(opt);
      });
    }

    // Render Tickets
    if (ticketsTbody) {
      ticketsTbody.innerHTML = '';
      tickets.forEach(t => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><strong style="font-family: 'JetBrains Mono', monospace; color: var(--text-main);">${escapeHtml(t.id)}</strong></td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${escapeHtml(t.customer)}</div>
            <div style="font-size: 0.74rem; color: #64748b;">${escapeHtml(t.phone)}</div>
          </td>
          <td style="font-size: 0.82rem; color: var(--text-body);">${escapeHtml(t.issue)}</td>
          <td>
            <select onchange="updateTicketStatus('${t.id}', this.value)" style="background: #ffffff; color: var(--text-main); border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 0.78rem; font-weight: 600;">
              <option value="OPEN" ${t.status === 'OPEN' ? 'selected' : ''}>OPEN</option>
              <option value="RESOLVED" ${t.status === 'RESOLVED' ? 'selected' : ''}>RESOLVED</option>
            </select>
          </td>
        `;
        ticketsTbody.appendChild(tr);
      });
    }
  } catch (err) {
    console.error('Failed to load groups or tickets:', err);
  }
}

// Whitelist Single Group Toggle
window.toggleGroupAllowed = async function(id, isAllowed) {
  try {
    const res = await fetch('/api/groups/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ groupId: id, allowed: isAllowed })
    });
    if (res.ok) {
      showToast(isAllowed ? '✅ AwaxBot enabled in group!' : '⛔ AwaxBot disabled in group (silent)');
      loadGroupsAndTickets();
    } else {
      const err = await res.json();
      showToast(err.error || 'Failed to update group setting', 'error');
    }
  } catch (e) {
    showToast('Failed to update group setting', 'error');
  }
};

// Search Group by Name Filter
const groupSearchInput = document.getElementById('group-search-input');
if (groupSearchInput) {
  groupSearchInput.addEventListener('input', () => {
    const q = groupSearchInput.value.toLowerCase().trim();
    if (!q) {
      renderGroupsTable(cachedGroupsData);
      return;
    }
    const filtered = cachedGroupsData.filter(g =>
      (g.subject || '').toLowerCase().includes(q) ||
      (g.id || '').toLowerCase().includes(q)
    );
    renderGroupsTable(filtered);
  });
}

// Group Mode Change
const selectGroupMode = document.getElementById('select-group-mode');
if (selectGroupMode) {
  selectGroupMode.addEventListener('change', async () => {
    try {
      const res = await fetch('/api/groups/mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: selectGroupMode.value })
      });
      if (res.ok) {
        showToast(`Group Mode updated: ${selectGroupMode.value}`);
        loadGroupsAndTickets();
      }
    } catch (e) {
      showToast('Failed to change group mode', 'error');
    }
  });
}

// Select All Groups Button
const btnSelectAllGroups = document.getElementById('btn-select-all-groups');
if (btnSelectAllGroups) {
  btnSelectAllGroups.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/groups/select-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allowed: true })
      });
      if (res.ok) {
        showToast('✅ AwaxBot enabled in all groups!');
        loadGroupsAndTickets();
      }
    } catch (e) {
      showToast('Failed to select all groups', 'error');
    }
  });
}

// Deselect All Groups Button
const btnDeselectAllGroups = document.getElementById('btn-deselect-all-groups');
if (btnDeselectAllGroups) {
  btnDeselectAllGroups.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/groups/select-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allowed: false })
      });
      if (res.ok) {
        showToast('⛔ AwaxBot disabled in all groups (silent everywhere)');
        loadGroupsAndTickets();
      }
    } catch (e) {
      showToast('Failed to deselect all groups', 'error');
    }
  });
}

window.toggleGroupMute = async function(id, currentMuted) {
  try {
    const res = await fetch(`/api/groups/${id}/toggle-mute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mute: !currentMuted })
    });
    if (res.ok) {
      showToast(`Group ${!currentMuted ? 'muted' : 'unmuted'} successfully`);
      loadGroupsAndTickets();
    } else {
      const err = await res.json();
      showToast(err.error || 'Failed to update group setting', 'error');
    }
  } catch (e) {
    showToast('Failed to update group setting', 'error');
  }
};

window.updateTicketStatus = async function(id, status) {
  try {
    const res = await fetch(`/api/tickets/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) showToast(`Ticket ${id} marked as ${status}`);
  } catch (e) {
    showToast('Failed to update status', 'error');
  }
};

// Groups Refresh Button
// Load 24-Hour Statuses
async function loadStatuses() {
  const tbody = document.getElementById('statuses-tbody');
  if (!tbody) return;
  try {
    const res = await fetch('/api/statuses');
    const list = await res.json();
    tbody.innerHTML = '';
    if (!Array.isArray(list) || list.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">
            No active 24-hour statuses. Post a status above or type <code>!status &lt;message&gt;</code> in any WhatsApp group!
          </td>
        </tr>
      `;
      return;
    }
    const now = Date.now();
    list.forEach(s => {
      const remainingMs = Math.max(0, s.expiresAt - now);
      const hours = Math.floor(remainingMs / (3600 * 1000));
      const mins = Math.floor((remainingMs % (3600 * 1000)) / (60 * 1000));

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div style="font-weight: 700; color: var(--text-main); font-size: 0.86rem;">
            ${s.isBroadcast ? '📱 WhatsApp Story (Broadcast)' : escapeHtml(s.groupName)}
          </div>
          <div style="font-size: 0.72rem; color: #64748b; font-family: 'JetBrains Mono', monospace;">${escapeHtml(s.groupId)}</div>
        </td>
        <td style="max-width: 340px; font-weight: 600; color: var(--text-main); font-size: 0.84rem; white-space: pre-wrap;">
          "${escapeHtml(s.text)}"
        </td>
        <td>
          <span style="font-size: 0.8rem; font-weight: 600; color: var(--text-body);">${escapeHtml(s.authorName)}</span>
        </td>
        <td>
          <span class="badge badge-warning" style="font-family: 'JetBrains Mono', monospace;">
            ⏳ ${hours}h ${mins}m left
          </span>
        </td>
        <td>
          <button class="btn-icon delete" onclick="deleteStatus('${s.id}')" title="Clear Status">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error('Failed to load statuses:', err);
  }
}

window.deleteStatus = async function(id) {
  if (!confirm('Are you sure you want to remove this 24-hour status?')) return;
  try {
    const res = await fetch(`/api/statuses/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('24-Hour status removed');
      loadStatuses();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
};

// Post 24-Hour Status form submission
const formPostStatus = document.getElementById('form-post-status');
if (formPostStatus) {
  formPostStatus.addEventListener('submit', async (e) => {
    e.preventDefault();
    const select = document.getElementById('status-target-select');
    const groupId = select.value;
    const selectedOpt = select.options[select.selectedIndex];
    const groupName = selectedOpt?.dataset?.name || 'Group Chat';
    const text = document.getElementById('status-text-input').value.trim();
    if (!text) return;

    const btn = document.getElementById('btn-post-status');
    btn.disabled = true;

    try {
      const res = await fetch('/api/statuses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          groupId,
          groupName,
          text,
          isBroadcast: groupId === 'status@broadcast'
        })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('24-Hour Status posted successfully!');
        document.getElementById('status-text-input').value = '';
        loadStatuses();
      } else {
        showToast(data.error || 'Failed to post status', 'error');
      }
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      btn.disabled = false;
    }
  });
}

// Refresh Statuses button
const btnRefreshStatuses = document.getElementById('btn-refresh-statuses');
if (btnRefreshStatuses) {
  btnRefreshStatuses.addEventListener('click', () => {
    loadStatuses();
    showToast('Statuses refreshed');
  });
}

const btnRefreshGroups = document.getElementById('btn-refresh-groups');
if (btnRefreshGroups) {
  btnRefreshGroups.addEventListener('click', () => {
    loadGroupsAndTickets();
    showToast('Groups list refreshed');
  });
}


// Initial boot
loadConfig();
loadAutoReplies();
loadStatuses();
loadGroupsAndTickets();

// --- Video Downloader UI Logic ---
let currentDownloadedVideo = null;

const formDownloader = document.getElementById('form-downloader');
const dlInputUrl = document.getElementById('dl-input-url');
const btnDlSubmit = document.getElementById('btn-dl-submit');
const dlResultCard = document.getElementById('dl-result-card');
const dlVideoElement = document.getElementById('dl-video-element');
const dlBadgePlatform = document.getElementById('dl-badge-platform');
const dlBadgeDuration = document.getElementById('dl-badge-duration');
const dlVideoTitle = document.getElementById('dl-video-title');
const dlVideoAuthor = document.getElementById('dl-video-author');
const dlVideoStatus = document.getElementById('dl-video-status');
const dlBtnDownload = document.getElementById('dl-btn-download');
const dlBtnToggleWa = document.getElementById('dl-btn-toggle-wa');
const dlWaBox = document.getElementById('dl-wa-box');
const dlWaRecipient = document.getElementById('dl-wa-recipient');
const dlBtnSendNow = document.getElementById('dl-btn-send-now');

if (formDownloader) {
  formDownloader.addEventListener('submit', async (e) => {
    e.preventDefault();
    const url = dlInputUrl.value.trim();
    if (!url) return;

    btnDlSubmit.disabled = true;
    const originalBtnHtml = btnDlSubmit.innerHTML;
    btnDlSubmit.innerHTML = `<span class="spinner" style="width: 16px; height: 16px; border-width: 2px;"></span> <span>Fetching...</span>`;

    try {
      showToast('Extracting HD video stream...');
      const res = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();

      if (!res.ok || !data.videoUrl) {
        throw new Error(data.error || 'Failed to download video from this link.');
      }

      currentDownloadedVideo = data;
      // Directly stream MP4 to HTML5 player so video immediately shows and plays
      dlVideoElement.src = `/api/video-proxy?url=${encodeURIComponent(data.videoUrl)}`;
      dlVideoElement.load();
      dlBadgePlatform.textContent = data.source || 'Social Media';
      dlBadgeDuration.textContent = data.duration || 'HD MP4';
      dlVideoTitle.textContent = data.title || 'Video File';
      dlVideoAuthor.textContent = '👤 ' + (data.author || data.source);
      dlVideoStatus.textContent = '⚡ Direct MP4 Ready';
      // Directly triggers .mp4 file attachment download to user's computer/phone
      dlBtnDownload.href = `/api/download-file?url=${encodeURIComponent(data.videoUrl)}&title=${encodeURIComponent(data.title || 'video')}`;

      dlResultCard.classList.remove('hidden');
      dlResultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      showToast(`Success! ${data.source} MP4 video ready.`, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      btnDlSubmit.disabled = false;
      btnDlSubmit.innerHTML = originalBtnHtml;
    }
  });
}

if (dlBtnToggleWa) {
  dlBtnToggleWa.addEventListener('click', () => {
    dlWaBox.classList.toggle('hidden');
    if (!dlWaBox.classList.contains('hidden')) {
      dlWaRecipient.focus();
    }
  });
}

if (dlBtnSendNow) {
  dlBtnSendNow.addEventListener('click', async () => {
    if (!currentDownloadedVideo || !currentDownloadedVideo.videoUrl) {
      showToast('Please fetch a video first', 'error');
      return;
    }
    const to = dlWaRecipient.value.trim();
    if (!to) {
      showToast('Please enter a WhatsApp phone number or group ID', 'error');
      return;
    }

    dlBtnSendNow.disabled = true;
    dlBtnSendNow.textContent = 'Sending...';

    try {
      const res = await fetch('/api/send-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to,
          url: currentDownloadedVideo.videoUrl
        })
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Failed to send video');

      showToast(`Video sent to ${to} on WhatsApp!`, 'success');
      dlWaBox.classList.add('hidden');
      dlWaRecipient.value = '';
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      dlBtnSendNow.disabled = false;
      dlBtnSendNow.textContent = 'Send';
    }
  });
}

// Bot Control Actions (Restart, Reset QR, Refresh)
const btnRestart = document.getElementById('btn-restart-bot');
if (btnRestart) {
  btnRestart.addEventListener('click', async () => {
    btnRestart.disabled = true;
    showToast('🔄 Restarting WhatsApp bot...');
    try {
      const res = await fetch('/api/restart', { method: 'POST' });
      if (res.ok) {
        showToast('✅ Bot restart command dispatched');
      } else {
        showToast('Failed to restart bot', 'error');
      }
    } catch (e) {
      showToast('Error restarting bot', 'error');
    } finally {
      setTimeout(() => { btnRestart.disabled = false; }, 3000);
    }
  });
}

const btnLogout = document.getElementById('btn-logout-bot');
if (btnLogout) {
  btnLogout.addEventListener('click', async () => {
    if (!confirm('Are you sure you want to reset session and generate a new QR code?')) return;
    btnLogout.disabled = true;
    showToast('⚠️ Resetting WhatsApp session...');
    try {
      const res = await fetch('/api/logout', { method: 'POST' });
      if (res.ok) {
        showToast('✅ Session reset. New QR code generating...');
      } else {
        showToast('Failed to reset session', 'error');
      }
    } catch (e) {
      showToast('Error resetting session', 'error');
    } finally {
      setTimeout(() => { btnLogout.disabled = false; }, 3000);
    }
  });
}

const btnRefreshStats = document.getElementById('btn-refresh-stats');
if (btnRefreshStats) {
  btnRefreshStats.addEventListener('click', () => {
    showToast('Refreshing...');
    location.reload();
  });
}
