import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { Store } from './lib/store.js';
import { botInstance } from './lib/bot.js';
import { downloadVideo } from './lib/downloader.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Socket.io Real-time connection
io.on('connection', (socket) => {
  // Send initial state on connection
  const currentStatus = botInstance.getStatus();
  socket.emit('status', currentStatus);
  socket.emit('logs', Store.getRecentLogs());

  socket.on('request_qr', () => {
    socket.emit('status', botInstance.getStatus());
  });
});

// Forward Bot Events to Socket.io
botInstance.on('status', (data) => {
  io.emit('status', botInstance.getStatus());
});

botInstance.on('qr', (data) => {
  io.emit('qr', data);
});

botInstance.on('message', (msg) => {
  io.emit('message', msg);
});

// Periodic Stats Emitter
setInterval(() => {
  io.emit('stats', botInstance.getStatus().stats);
}, 5000);

// --- REST API ENDPOINTS ---

// Bot status
app.get('/api/status', (req, res) => {
  res.json(botInstance.getStatus());
});

// Config
app.get('/api/config', (req, res) => {
  res.json(Store.getConfig());
});

app.post('/api/config', (req, res) => {
  const updated = Store.updateConfig(req.body);
  res.json({ success: true, config: updated });
});

// Auto-Replies
app.get('/api/replies', (req, res) => {
  res.json(Store.getAutoReplies());
});

app.post('/api/replies', (req, res) => {
  const { trigger, matchType, reply, enabled } = req.body;
  if (!trigger || !reply) {
    return res.status(400).json({ error: 'Trigger and reply text are required.' });
  }
  const created = Store.addAutoReply({ trigger, matchType, reply, enabled });
  res.status(201).json(created);
});

app.put('/api/replies/:id', (req, res) => {
  const updated = Store.updateAutoReply(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Not found' });
  res.json(updated);
});

app.delete('/api/replies/:id', (req, res) => {
  Store.deleteAutoReply(req.params.id);
  res.json({ success: true });
});

// 24-Hour Statuses (Group 24h Status & WhatsApp Story Broadcast)
app.get('/api/statuses', (req, res) => {
  res.json(Store.getStatuses());
});

app.post('/api/statuses', async (req, res) => {
  const { groupId, groupName, text, isBroadcast } = req.body;
  if (!text) return res.status(400).json({ error: 'Status message is required' });
  try {
    if (isBroadcast || groupId === 'status@broadcast') {
      try {
        await botInstance.postWhatsAppStatus(text);
      } catch (e) {
        console.warn('WhatsApp status broadcast notice:', e.message);
      }
    } else if (groupId && groupId.endsWith('@g.us')) {
      try {
        await botInstance.postGroupStatus(groupId, text);
      } catch (e) {
        console.warn('WhatsApp group status post notice:', e.message);
      }
    }
    const created = Store.setGroupStatus({
      groupId: isBroadcast ? 'status@broadcast' : groupId,
      groupName: isBroadcast ? 'WhatsApp Story (Broadcast)' : (groupName || 'Group Chat'),
      text,
      author: 'Dashboard',
      authorName: 'Dashboard Admin',
      isBroadcast: !!isBroadcast
    });
    res.status(201).json(created);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/statuses/:id', (req, res) => {
  Store.deleteStatus(req.params.id);
  res.json({ success: true });
});

// Groups Management & Whitelist Access Control
app.get('/api/groups', async (req, res) => {
  try {
    const groups = await botInstance.getAllGroups();
    const settings = Store.getGroupSettings();
    res.json({
      mode: settings.mode || 'whitelist',
      allowedGroups: settings.allowedGroups || [],
      totalJoined: groups.length,
      totalAllowed: groups.filter(g => g.isAllowed).length,
      groups
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/groups/toggle', (req, res) => {
  const { groupId, allowed } = req.body;
  if (!groupId) return res.status(400).json({ error: 'groupId is required' });
  const result = Store.toggleGroupAllowed(groupId, allowed);
  res.json(result);
});

app.post('/api/groups/mode', (req, res) => {
  const { mode } = req.body;
  if (!['whitelist', 'all', 'disabled'].includes(mode)) {
    return res.status(400).json({ error: 'Invalid mode. Allowed: whitelist, all, disabled' });
  }
  const result = Store.setGroupMode(mode);
  res.json(result);
});

app.post('/api/groups/select-all', async (req, res) => {
  try {
    const { allowed } = req.body;
    if (allowed) {
      const groups = await botInstance.getAllGroups();
      const allIds = groups.map(g => g.id);
      Store.setAllowedGroups(allIds);
      res.json({ success: true, count: allIds.length, allowedGroups: allIds });
    } else {
      Store.setAllowedGroups([]);
      res.json({ success: true, count: 0, allowedGroups: [] });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/groups/:id/toggle-mute', async (req, res) => {
  try {
    const { id } = req.params;
    const { mute } = req.body;
    await botInstance.setGroupMute(id, mute);
    res.json({ success: true, message: `Group ${mute ? 'muted' : 'unmuted'} successfully` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Support Tickets
app.get('/api/tickets', (req, res) => {
  res.json(Store.getTickets());
});

app.post('/api/tickets', (req, res) => {
  const { customer, phone, issue, priority } = req.body;
  if (!issue) return res.status(400).json({ error: 'Issue is required' });
  const created = Store.addTicket({ customer, phone, issue, priority });
  res.status(201).json(created);
});

app.put('/api/tickets/:id/status', (req, res) => {
  const updated = Store.updateTicketStatus(req.params.id, req.body.status);
  if (!updated) return res.status(404).json({ error: 'Ticket not found' });
  res.json(updated);
});

// Message Logs
app.get('/api/logs', (req, res) => {
  res.json(Store.getRecentLogs());
});

// Send WhatsApp message
app.post('/api/send', async (req, res) => {
  const { to, message } = req.body;
  if (!to || !message) {
    return res.status(400).json({ error: 'Phone number and message are required' });
  }

  // Format recipient jid
  let jid = to.trim();
  if (!jid.includes('@')) {
    // Remove +, spaces, hyphens
    const cleanNumber = jid.replace(/[^0-9]/g, '');
    jid = `${cleanNumber}@s.whatsapp.net`;
  }

  try {
    await botInstance.sendMessage(jid, message);
    res.json({ success: true, message: 'Message sent successfully!' });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to send message' });
  }
});

// All Video Downloader Endpoints
app.post('/api/download', async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'Please provide a video URL.' });
  }
  try {
    const videoData = await downloadVideo(url);
    res.json({ success: true, ...videoData });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to download video.' });
  }
});

app.post('/api/send-video', async (req, res) => {
  const { to, url } = req.body;
  if (!to || !url) {
    return res.status(400).json({ error: 'Recipient phone number and video URL are required.' });
  }

  let jid = to.trim();
  if (!jid.includes('@')) {
    const cleanNumber = jid.replace(/[^0-9]/g, '');
    jid = `${cleanNumber}@s.whatsapp.net`;
  }

  try {
    const videoData = await downloadVideo(url);
    await botInstance.sendVideoFromUrl(jid, videoData);
    res.json({ success: true, message: `Video successfully sent to ${to}!`, video: videoData });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to download and send video.' });
  }
});

// Direct MP4 Attachment File Downloader (Direct to Disk as .mp4)
app.get('/api/download-file', async (req, res) => {
  const { url, title } = req.query;
  if (!url) return res.status(400).send('Video URL is required');

  try {
    const fetchRes = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'video/mp4,video/*,*/*;q=0.9',
        'Referer': url
      }
    });

    if (!fetchRes.ok) {
      return res.status(fetchRes.status).send('Failed to fetch remote MP4 stream.');
    }

    const safeTitle = (title || 'video')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .replace(/_+/g, '_')
      .slice(0, 50) || 'video';

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${safeTitle}.mp4"`);

    const { Readable } = await import('stream');
    Readable.fromWeb(fetchRes.body).pipe(res);
  } catch (err) {
    console.error('Direct MP4 download error:', err.message);
    if (!res.headersSent) res.status(500).send(err.message);
  }
});

// Direct MP4 Video Stream Proxy (Removes CORS / Hotlink restrictions for instant player display)
app.get('/api/video-proxy', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).send('Video URL is required');

  try {
    const fetchRes = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'video/mp4,video/*,*/*;q=0.9',
        'Referer': url
      }
    });

    res.setHeader('Content-Type', fetchRes.headers.get('content-type') || 'video/mp4');
    const { Readable } = await import('stream');
    Readable.fromWeb(fetchRes.body).pipe(res);
  } catch (err) {
    if (!res.headersSent) res.status(500).send(err.message);
  }
});

// Session Actions
app.post('/api/restart', async (req, res) => {
  await botInstance.restart();
  res.json({ success: true, message: 'Bot restart initiated' });
});

app.post('/api/logout', async (req, res) => {
  await botInstance.logout();
  res.json({ success: true, message: 'Logged out. New QR code being generated.' });
});

// Start Server and Bot
server.listen(PORT, () => {
  console.log(`\n==================================================`);
  console.log(`🚀 WhatsApp SuperBot Dashboard: http://localhost:${PORT}`);
  console.log(`==================================================\n`);
  
  // Launch Bot
  botInstance.init();
});

process.on('uncaughtException', (err) => {
  console.error('Unhandled process exception:', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled process rejection:', reason);
});

